// API layer - calls Flask backend at localhost:5000
const BASE_URL = "http://localhost:5000/api";

// Helper to make API calls
async function apiFetch(
  path: string,
  options: RequestInit = {},
  token?: string
): Promise<any> {
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
  };
  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }

  const res = await fetch(`${BASE_URL}${path}`, {
    ...options,
    headers: { ...headers, ...((options.headers as Record<string, string>) || {}) },
  });

  const data = await res.json();

  if (!data.success) {
    throw new Error(data.error || "Request failed");
  }

  return data;
}

// Auth API
export const authApi = {
  async signup(email: string, password: string, firstName: string, lastName: string, role: "admin" | "trainee" = "trainee") {
    return apiFetch("/auth/signup", { method: "POST", body: JSON.stringify({ email, password, firstName, lastName, role }) });
  },
  async signin(email: string, password: string) {
    return apiFetch("/auth/signin", { method: "POST", body: JSON.stringify({ email, password }) });
  },
  async getUser(accessToken: string) {
    return apiFetch("/auth/user", {}, accessToken);
  },
  async signout(accessToken: string) {
    return apiFetch("/auth/signout", { method: "POST" }, accessToken);
  },
};

// Track API
export const trackApi = {
  async selectTrack(accessToken: string, trackId: string) {
    return apiFetch("/track/select", { method: "POST", body: JSON.stringify({ trackId }) }, accessToken);
  },
  async getSelectedTrack(accessToken: string) {
    return apiFetch("/track", {}, accessToken);
  },
};

// Progress API
export const progressApi = {
  async getProgress(accessToken: string, trackId: string) {
    return apiFetch(`/progress/${trackId}`, {}, accessToken);
  },
  async markCourseComplete(accessToken: string, trackId: string, moduleIndex: number, courseIndex: number) {
    return apiFetch("/progress/course", { method: "POST", body: JSON.stringify({ trackId, moduleIndex, courseIndex }) }, accessToken);
  },
};

// Quiz API
export const quizApi = {
  async submitQuiz(accessToken: string, trackId: string, moduleIndex: number, score: number) {
    return apiFetch("/progress/quiz", { method: "POST", body: JSON.stringify({ trackId, moduleIndex, score }) }, accessToken);
  },
};

// Admin API
export const adminApi = {
  async getUsers(accessToken: string) {
    return apiFetch("/admin/users", {}, accessToken);
  },
  async getReports(accessToken: string) {
    return apiFetch("/admin/reports", {}, accessToken);
  },
  async deleteUser(accessToken: string, userId: string) {
    return apiFetch(`/admin/users/${userId}`, { method: "DELETE" }, accessToken);
  },
};

// Notification API (stub)
export const notificationApi = {
  async sendEmail(accessToken: string, to: string, subject: string, body: string) {
    console.log("Email stub:", { to, subject, body });
    return { success: true };
  },
};
