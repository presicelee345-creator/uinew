// Track order - determines which tracks must be completed sequentially
export const trackOrder = [
  "president",
  "vice-president",
  "second-vice-president",
  "third-vice-president",
  "treasurer",
  "financial-secretary",
  "corresponding-secretary",
  "chaplain",
  "parliamentarian",
];

export const trainingData: Record<string, any> = {
  president: {
    name: "President",
    description:
      "The President's role demands strategic thinking, leadership, communication, and conflict-resolution skills.",
    attributes: [
      {
        title: "Leadership & Strategic Visioning",
        description:
          "Overview of leadership styles, strategic planning, and setting organizational vision and goals.",
        courses: [
          {
            title: "What is Strategic Planning?",
            platform: "LinkedIn Learning",
            duration: "20 mins",
            link: "https://www.linkedin.com/learning/strategic-planning-foundations",
          },
          {
            title: "Creating Your Personal Leadership Plan",
            platform: "Coursera",
            duration: "45 mins",
            link: "https://www.coursera.org/learn/leadership-principles",
          },
          {
            title: "Leadership Fundamentals",
            platform: "YouTube by FutureLearn",
            duration: "30 mins",
            link: "https://www.youtube.com/watch?v=Vr2bBXD8wgk",
          },
          {
            title: "Strategic Thinking",
            platform: "LinkedIn Learning",
            duration: "50 mins",
            link: "https://www.linkedin.com/learning/strategic-thinking",
          },
          {
            title: "Defining Your Leadership Values and Vision",
            platform: "Coursera",
            duration: "30 mins",
            link: "https://www.coursera.org/learn/leadership-and-influence",
          },
        ],
        quiz: {
          title: "Leadership & Strategic Visioning Assessment",
          duration: "10 mins",
        },
      },
      {
        title: "Effective Public Speaking & Communication",
        description:
          "Techniques for public speaking, clear communication, and inspiring team engagement.",
        courses: [
          {
            title: "Introduction to Public Speaking",
            platform: "YouTube by Udemy",
            duration: "30 mins",
            link: "https://www.youtube.com/watch?v=K0pxo-dS9Hc",
          },
          {
            title: "Speak Confidently and Improve Communication Skills",
            platform: "Coursera",
            duration: "45 mins",
            link: "https://www.coursera.org/learn/public-speaking",
          },
          {
            title: "Public Speaking Essentials",
            platform: "Skillshare",
            duration: "30 mins",
            link: "https://www.skillshare.com/classes/public-speaking",
          },
          {
            title: "Effective Communication in the Workplace",
            platform: "LinkedIn Learning",
            duration: "45 mins",
            link: "https://www.linkedin.com/learning/communicating-with-confidence",
          },
          {
            title: "Confidence on Camera",
            platform: "YouTube by Stanford",
            duration: "50 mins",
            link: "https://www.youtube.com/watch?v=XIXvKKEQQJo",
          },
        ],
        quiz: {
          title: "Public Speaking & Communication Quiz",
          duration: "12 mins",
        },
      },
      {
        title: "Conflict Resolution & Mediation",
        description:
          "Strategies for managing and resolving conflicts within a team or organization.",
        courses: [
          {
            title: "Managing Conflict in Teams",
            platform: "LinkedIn Learning",
            duration: "40 mins",
            link: "https://www.linkedin.com/learning/managing-team-conflict",
          },
          {
            title: "Resolving Conflict in the Workplace",
            platform: "Coursera",
            duration: "50 mins",
            link: "https://www.coursera.org/learn/conflict-resolution",
          },
          {
            title: "Conflict Resolution Skills",
            platform: "Skillshare",
            duration: "30 mins",
            link: "https://www.skillshare.com/classes/conflict-resolution",
          },
          {
            title: "Conflict Resolution at Work",
            platform: "YouTube by UC Berkeley",
            duration: "40 mins",
            link: "https://www.youtube.com/watch?v=gIVTd5euedk",
          },
          {
            title: "Introduction to Negotiation",
            platform: "YouTube by Yale",
            duration: "60 mins",
            link: "https://www.youtube.com/watch?v=1MXIrDqiZKE",
          },
        ],
        quiz: {
          title: "Conflict Resolution & Mediation Quiz",
          duration: "15 mins",
        },
      },
      {
        title: "Delegation & Time Management",
        description:
          "Best practices for prioritizing tasks, delegating effectively, and managing time.",
        courses: [
          {
            title: "Effective Delegation Skills",
            platform: "LinkedIn Learning",
            duration: "35 mins",
            link: "https://www.linkedin.com/learning/delegating-tasks-to-your-team",
          },
          {
            title: "Time Management Tips",
            platform: "Coursera",
            duration: "30 mins",
            link: "https://www.coursera.org/learn/work-smarter-not-harder",
          },
          {
            title: "Introduction to Time Management",
            platform: "Skillshare",
            duration: "25 mins",
            link: "https://www.skillshare.com/classes/time-management",
          },
          {
            title: "Delegating Effectively",
            platform: "YouTube by LinkedIn Learning",
            duration: "40 mins",
            link: "https://www.youtube.com/watch?v=9yJWKwPAVoc",
          },
          {
            title: "Mastering Prioritization",
            platform: "YouTube by Udemy",
            duration: "30 mins",
            link: "https://www.youtube.com/watch?v=5-0E75a9AJc",
          },
        ],
        quiz: {
          title: "Delegation & Time Management Quiz",
          duration: "12 mins",
        },
      },
      {
        title: "Organizational Culture & Ethics",
        description:
          "Building an inclusive, positive culture and understanding ethical responsibilities.",
        courses: [
          {
            title: "Ethics and Organizational Culture",
            platform: "YouTube by Harvard",
            duration: "45 mins",
            link: "https://www.youtube.com/watch?v=6mHEy-r0s5U",
          },
          {
            title: "What is Organizational Culture?",
            platform: "LinkedIn Learning",
            duration: "30 mins",
            link: "https://www.linkedin.com/learning/organizational-culture",
          },
          {
            title: "Building an Inclusive Culture",
            platform: "Coursera",
            duration: "40 mins",
            link: "https://www.coursera.org/learn/diversity-inclusion-culture",
          },
          {
            title: "Ethics for Leaders",
            platform: "YouTube by FutureLearn",
            duration: "45 mins",
            link: "https://www.youtube.com/watch?v=mXVbGDUX-5o",
          },
          {
            title: "Culture and Leadership",
            platform: "YouTube by Skillshare",
            duration: "50 mins",
            link: "https://www.youtube.com/watch?v=k_F-7a4KLFk",
          },
        ],
        quiz: {
          title: "Organizational Culture & Ethics Quiz",
          duration: "15 mins",
        },
      },
    ],
  },
  "vice-president": {
    name: "Vice President",
    description:
      "The Vice President supports the President and steps in as needed, so training should focus on adaptability, team support, and coordination.",
    attributes: [
      {
        title: "Project Management Essentials",
        description:
          "Key project management principles to keep initiatives on track and within scope.",
        courses: [
          {
            title: "Introduction to Project Management",
            platform: "LinkedIn Learning",
            duration: "45 mins",
          },
          {
            title: "Project Planning Basics",
            platform: "YouTube by PMI",
            duration: "50 mins",
          },
          {
            title: "Essentials of Project Management",
            platform: "Coursera",
            duration: "40 mins",
          },
          {
            title: "Project Management Foundations",
            platform: "LinkedIn Learning",
            duration: "60 mins",
          },
          {
            title: "Understanding Project Lifecycles",
            platform: "Skillshare",
            duration: "40 mins",
          },
        ],
        quiz: {
          title: "Project Management Essentials Quiz",
          duration: "15 mins",
        },
      },
      {
        title: "Effective Communication & Team Dynamics",
        description:
          "Methods for supporting and enhancing team dynamics and communication as the President's key collaborator.",
        courses: [
          {
            title: "Building a Great Team",
            platform: "LinkedIn Learning",
            duration: "30 mins",
          },
          {
            title: "Team Communication Skills",
            platform: "Skillshare",
            duration: "25 mins",
          },
          {
            title: "Communicating Effectively as a Leader",
            platform: "YouTube by Stanford",
            duration: "50 mins",
          },
          {
            title: "Effective Team Communication",
            platform: "Coursera",
            duration: "40 mins",
          },
          {
            title: "Building a Culture of Feedback",
            platform: "LinkedIn Learning",
            duration: "50 mins",
          },
        ],
        quiz: {
          title: "Communication & Team Dynamics Quiz",
          duration: "12 mins",
        },
      },
      {
        title: "Strategic Planning & Operational Support",
        description:
          "Understanding strategic planning and providing operational support to implement initiatives.",
        courses: [
          {
            title: "Basics of Strategic Planning",
            platform: "YouTube by Harvard",
            duration: "35 mins",
          },
          {
            title: "Operational Strategy for Managers",
            platform: "Coursera",
            duration: "45 mins",
          },
          {
            title: "Strategic Planning Simplified",
            platform: "Skillshare",
            duration: "30 mins",
          },
          {
            title: "Intro to Strategic Operations",
            platform: "YouTube by FutureLearn",
            duration: "40 mins",
          },
          {
            title: "Implementing Strategy",
            platform: "LinkedIn Learning",
            duration: "55 mins",
          },
        ],
        quiz: {
          title: "Strategic Planning & Operations Quiz",
          duration: "15 mins",
        },
      },
      {
        title: "Succession Planning & Mentorship",
        description:
          "Training on developing future leaders and creating a sustainable succession plan.",
        courses: [
          {
            title: "Mentoring and Coaching Skills",
            platform: "LinkedIn Learning",
            duration: "50 mins",
          },
          {
            title: "Creating a Mentorship Culture",
            platform: "Skillshare",
            duration: "45 mins",
          },
          {
            title: "Planning for Leadership Succession",
            platform: "Coursera",
            duration: "50 mins",
          },
          {
            title: "Effective Mentorship for Managers",
            platform: "YouTube by Harvard",
            duration: "30 mins",
          },
          {
            title: "How to Create a Succession Plan",
            platform: "LinkedIn Learning",
            duration: "55 mins",
          },
        ],
        quiz: {
          title: "Succession Planning & Mentorship Quiz",
          duration: "15 mins",
        },
      },
      {
        title: "Risk Management & Crisis Response",
        description:
          "Preparing for and managing unexpected challenges, ensuring organizational continuity.",
        courses: [
          {
            title: "Crisis Management Essentials",
            platform: "YouTube by Udemy",
            duration: "30 mins",
          },
          {
            title: "Risk Management for Leaders",
            platform: "LinkedIn Learning",
            duration: "45 mins",
          },
          {
            title: "Introduction to Crisis Response",
            platform: "Coursera",
            duration: "40 mins",
          },
          {
            title: "Managing Risk in Projects",
            platform: "Skillshare",
            duration: "30 mins",
          },
          {
            title: "Crisis Management in Organizations",
            platform: "YouTube by PMI",
            duration: "50 mins",
          },
        ],
        quiz: {
          title: "Risk Management & Crisis Response Quiz",
          duration: "15 mins",
        },
      },
    ],
  },
  "second-vice-president": {
    name: "Second Vice President",
    description:
      "This role often involves supporting both the President and Vice President in various capacities, with a focus on organization and team oversight.",
    attributes: [
      {
        title: "Administrative Oversight & Best Practices",
        description:
          "An overview of effective administrative management, including record-keeping and documentation.",
        courses: [
          {
            title: "Administrative Skills Essentials",
            platform: "LinkedIn Learning",
            duration: "50 mins",
          },
          {
            title: "Best Practices for Effective Administration",
            platform: "Coursera",
            duration: "40 mins",
          },
          {
            title: "Managing Office Operations",
            platform: "YouTube by Harvard",
            duration: "30 mins",
          },
          {
            title: "Basics of Office Administration",
            platform: "Skillshare",
            duration: "25 mins",
          },
          {
            title: "Overseeing Teams and Operations",
            platform: "LinkedIn Learning",
            duration: "55 mins",
          },
        ],
        quiz: {
          title: "Administrative Oversight Quiz",
          duration: "12 mins",
        },
      },
      {
        title: "Event Planning & Coordination",
        description:
          "Essential skills for planning, coordinating, and managing organizational events.",
        courses: [
          {
            title: "Introduction to Event Planning",
            platform: "LinkedIn Learning",
            duration: "30 mins",
          },
          {
            title: "Essentials of Event Planning",
            platform: "YouTube by Eventbrite",
            duration: "50 mins",
          },
          {
            title: "Event Planning Foundations",
            platform: "Coursera",
            duration: "40 mins",
          },
          {
            title: "How to Coordinate Events",
            platform: "Skillshare",
            duration: "25 mins",
          },
          {
            title: "Effective Event Planning",
            platform: "LinkedIn Learning",
            duration: "50 mins",
          },
        ],
        quiz: {
          title: "Event Planning & Coordination Quiz",
          duration: "15 mins",
        },
      },
      {
        title: "Team Leadership & Motivation",
        description:
          "Tools for motivating team members and leading smaller task forces or committees.",
        courses: [
          {
            title: "Motivating Your Team",
            platform: "YouTube by Harvard",
            duration: "40 mins",
          },
          {
            title: "Team Leadership Skills",
            platform: "Coursera",
            duration: "50 mins",
          },
          {
            title: "Creating Motivation at Work",
            platform: "Skillshare",
            duration: "30 mins",
          },
          {
            title: "How to Inspire Your Team",
            platform: "LinkedIn Learning",
            duration: "45 mins",
          },
          {
            title: "Leading Teams Effectively",
            platform: "YouTube by FutureLearn",
            duration: "30 mins",
          },
        ],
        quiz: {
          title: "Team Leadership & Motivation Quiz",
          duration: "12 mins",
        },
      },
      {
        title: "Data-Driven Decision Making",
        description:
          "Techniques for analyzing data and making informed decisions that benefit the organization.",
        courses: [
          {
            title: "Intro to Data-Driven Decisions",
            platform: "LinkedIn Learning",
            duration: "50 mins",
          },
          {
            title: "Basics of Data Analysis",
            platform: "Coursera",
            duration: "45 mins",
          },
          {
            title: "Using Data to Make Decisions",
            platform: "YouTube by Udacity",
            duration: "40 mins",
          },
          {
            title: "Interpreting Data for Leaders",
            platform: "Skillshare",
            duration: "25 mins",
          },
          {
            title: "Analytics for Nonprofits",
            platform: "LinkedIn Learning",
            duration: "55 mins",
          },
        ],
        quiz: {
          title: "Data-Driven Decision Making Quiz",
          duration: "15 mins",
        },
      },
      {
        title: "Financial Basics for Nonprofits",
        description:
          "Basic financial management skills to support the Treasurer and ensure budget compliance.",
        courses: [
          {
            title: "Introduction to Nonprofit Finance",
            platform: "LinkedIn Learning",
            duration: "30 mins",
          },
          {
            title: "Basics of Budgeting for Nonprofits",
            platform: "Coursera",
            duration: "50 mins",
          },
          {
            title: "Financial Literacy for Nonprofit Leaders",
            platform: "YouTube by Candid",
            duration: "45 mins",
          },
          {
            title: "Understanding Nonprofit Finances",
            platform: "Skillshare",
            duration: "30 mins",
          },
          {
            title: "Finance Essentials for Nonprofits",
            platform: "LinkedIn Learning",
            duration: "40 mins",
          },
        ],
        quiz: {
          title: "Financial Basics for Nonprofits Quiz",
          duration: "15 mins",
        },
      },
    ],
  },
  "third-vice-president": {
    name: "Third Vice President",
    description:
      "The Third Vice President often serves as a liaison between teams, assisting with organizational communication and project support.",
    attributes: [
      {
        title: "Communication & Interpersonal Skills",
        description:
          "Techniques for improving communication and building strong interpersonal relationships within the organization.",
        courses: [
          {
            title: "Developing Interpersonal Skills for the Workplace",
            platform: "LinkedIn Learning",
            duration: "40 mins",
          },
          {
            title: "Effective Communication Skills",
            platform: "YouTube by Udemy",
            duration: "45 mins",
          },
          {
            title: "Interpersonal Communication Basics",
            platform: "Coursera",
            duration: "30 mins",
          },
          {
            title: "Building Strong Interpersonal Relationships",
            platform: "Skillshare",
            duration: "25 mins",
          },
          {
            title: "Fundamentals of Communication",
            platform: "LinkedIn Learning",
            duration: "50 mins",
          },
        ],
        quiz: {
          title: "Communication & Interpersonal Skills Quiz",
          duration: "12 mins",
        },
      },
      {
        title: "Program Development & Evaluation",
        description:
          "Learning to develop, assess, and improve organizational programs effectively.",
        courses: [
          {
            title: "Basics of Program Planning",
            platform: "LinkedIn Learning",
            duration: "40 mins",
          },
          {
            title: "Program Evaluation Essentials",
            platform: "YouTube by FutureLearn",
            duration: "45 mins",
          },
          {
            title: "Designing and Evaluating Programs",
            platform: "Coursera",
            duration: "50 mins",
          },
          {
            title: "Introduction to Project Evaluation",
            platform: "Skillshare",
            duration: "30 mins",
          },
          {
            title: "Program Development Techniques",
            platform: "LinkedIn Learning",
            duration: "55 mins",
          },
        ],
        quiz: {
          title: "Program Development & Evaluation Quiz",
          duration: "15 mins",
        },
      },
      {
        title: "Volunteer Recruitment & Retention",
        description:
          "Strategies for recruiting and retaining engaged, long-term volunteers.",
        courses: [
          {
            title: "Volunteer Management Essentials",
            platform: "LinkedIn Learning",
            duration: "30 mins",
          },
          {
            title: "How to Recruit and Retain Volunteers",
            platform: "YouTube by Candid",
            duration: "40 mins",
          },
          {
            title: "Engaging Volunteers Effectively",
            platform: "Coursera",
            duration: "50 mins",
          },
          {
            title: "Volunteer Onboarding and Engagement",
            platform: "Skillshare",
            duration: "25 mins",
          },
          {
            title: "Volunteer Recruitment Basics",
            platform: "LinkedIn Learning",
            duration: "45 mins",
          },
        ],
        quiz: {
          title: "Volunteer Recruitment & Retention Quiz",
          duration: "12 mins",
        },
      },
      {
        title: "Basic Financial Literacy for Leadership",
        description:
          "Basic budgeting and financial monitoring to provide support in financial matters.",
        courses: [
          {
            title: "Finance Basics for Nonprofit Leaders",
            platform: "LinkedIn Learning",
            duration: "30 mins",
          },
          {
            title: "Understanding Nonprofit Finances",
            platform: "YouTube by Candid",
            duration: "40 mins",
          },
          {
            title: "Financial Literacy Essentials",
            platform: "Coursera",
            duration: "50 mins",
          },
          {
            title: "Intro to Budgeting and Finance",
            platform: "Skillshare",
            duration: "25 mins",
          },
          {
            title: "Basic Finance for Nonprofits",
            platform: "LinkedIn Learning",
            duration: "45 mins",
          },
        ],
        quiz: {
          title: "Financial Literacy for Leadership Quiz",
          duration: "15 mins",
        },
      },
      {
        title: "Diversity, Equity, & Inclusion Training",
        description:
          "Fostering an inclusive environment that values diverse perspectives and backgrounds.",
        courses: [
          {
            title: "Introduction to Diversity and Inclusion",
            platform: "LinkedIn Learning",
            duration: "45 mins",
          },
          {
            title: "Promoting an Inclusive Culture",
            platform: "Coursera",
            duration: "50 mins",
          },
          {
            title: "Basics of Cultural Competency",
            platform: "YouTube by Harvard",
            duration: "40 mins",
          },
          {
            title: "Diversity and Inclusion in the Workplace",
            platform: "Skillshare",
            duration: "25 mins",
          },
          {
            title: "Creating an Inclusive Environment",
            platform: "LinkedIn Learning",
            duration: "55 mins",
          },
        ],
        quiz: {
          title: "Diversity, Equity, & Inclusion Quiz",
          duration: "15 mins",
        },
      },
    ],
  },
  treasurer: {
    name: "Treasurer",
    description:
      "The Treasurer handles financial planning, budgeting, and record-keeping for the organization.",
    attributes: [
      {
        title: "Nonprofit Financial Management",
        description:
          "Principles of managing finances specific to nonprofit organizations, including accounting basics.",
        courses: [
          {
            title: "Nonprofit Finance Basics",
            platform: "LinkedIn Learning",
            duration: "30 mins",
          },
          {
            title: "Essentials of Nonprofit Management",
            platform: "Coursera",
            duration: "50 mins",
          },
          {
            title: "Managing Nonprofit Finances",
            platform: "YouTube by Candid",
            duration: "40 mins",
          },
          {
            title: "Financial Stewardship for Nonprofits",
            platform: "Skillshare",
            duration: "35 mins",
          },
          {
            title: "Finance Essentials for Treasurers",
            platform: "LinkedIn Learning",
            duration: "45 mins",
          },
        ],
        quiz: {
          title: "Nonprofit Financial Management Quiz",
          duration: "15 mins",
        },
      },
      {
        title: "Budgeting & Financial Planning",
        description:
          "Techniques for creating and maintaining a budget that aligns with organizational goals.",
        courses: [
          {
            title: "Budgeting Basics",
            platform: "YouTube by Skillshare",
            duration: "40 mins",
          },
          {
            title: "Budgeting for Nonprofits",
            platform: "LinkedIn Learning",
            duration: "45 mins",
          },
          {
            title: "Financial Planning for Leaders",
            platform: "Coursera",
            duration: "50 mins",
          },
          {
            title: "Creating Effective Budgets",
            platform: "YouTube by Candid",
            duration: "30 mins",
          },
          {
            title: "Intro to Budget Management",
            platform: "Skillshare",
            duration: "25 mins",
          },
        ],
        quiz: {
          title: "Budgeting & Financial Planning Quiz",
          duration: "15 mins",
        },
      },
      {
        title: "Financial Reporting & Analysis",
        description:
          "How to prepare and analyze financial statements, reports, and compliance documents.",
        courses: [
          {
            title: "Financial Analysis Basics",
            platform: "LinkedIn Learning",
            duration: "40 mins",
          },
          {
            title: "Nonprofit Financial Statements",
            platform: "YouTube by Candid",
            duration: "50 mins",
          },
          {
            title: "Intro to Financial Analysis",
            platform: "Coursera",
            duration: "45 mins",
          },
          {
            title: "How to Analyze Financial Reports",
            platform: "LinkedIn Learning",
            duration: "55 mins",
          },
          {
            title: "Understanding Financial Statements",
            platform: "Skillshare",
            duration: "35 mins",
          },
        ],
        quiz: {
          title: "Financial Reporting & Analysis Quiz",
          duration: "15 mins",
        },
      },
      {
        title: "Ethics & Accountability in Financial Management",
        description:
          "Maintaining ethical standards and accountability in managing funds.",
        courses: [
          {
            title: "Ethics in Finance",
            platform: "YouTube by LinkedIn Learning",
            duration: "30 mins",
          },
          {
            title: "Accountability in Nonprofit Management",
            platform: "Coursera",
            duration: "45 mins",
          },
          {
            title: "Financial Responsibility and Ethics",
            platform: "Skillshare",
            duration: "35 mins",
          },
          {
            title: "Ethical Leadership in Finance",
            platform: "LinkedIn Learning",
            duration: "55 mins",
          },
          {
            title: "Basics of Nonprofit Accountability",
            platform: "YouTube by Candid",
            duration: "30 mins",
          },
        ],
        quiz: {
          title: "Ethics & Accountability Quiz",
          duration: "12 mins",
        },
      },
      {
        title: "Grant Writing & Fundraising Basics",
        description:
          "Skills for identifying and applying for grants and basic fundraising techniques.",
        courses: [
          {
            title: "Introduction to Grant Writing",
            platform: "LinkedIn Learning",
            duration: "45 mins",
          },
          {
            title: "Basics of Fundraising",
            platform: "Coursera",
            duration: "50 mins",
          },
          {
            title: "Nonprofit Fundraising Essentials",
            platform: "YouTube by Candid",
            duration: "40 mins",
          },
          {
            title: "How to Write a Grant Proposal",
            platform: "Skillshare",
            duration: "25 mins",
          },
          {
            title: "Grant Writing for Beginners",
            platform: "LinkedIn Learning",
            duration: "50 mins",
          },
        ],
        quiz: {
          title: "Grant Writing & Fundraising Quiz",
          duration: "15 mins",
        },
      },
    ],
  },
  "financial-secretary": {
    name: "Financial Secretary",
    description:
      "The Financial Secretary supports the Treasurer and manages financial records, donations, and receipts.",
    attributes: [
      {
        title: "Record-Keeping & Documentation",
        description:
          "Techniques for organizing and maintaining accurate financial records.",
        courses: [
          {
            title: "Basics of Record-Keeping",
            platform: "YouTube by NonprofitReady",
            duration: "40 mins",
          },
          {
            title: "Effective Document Management",
            platform: "LinkedIn Learning",
            duration: "30 mins",
          },
          {
            title: "How to Organize Your Files",
            platform: "Skillshare",
            duration: "25 mins",
          },
          {
            title: "Administrative Record Management",
            platform: "YouTube by Udemy",
            duration: "45 mins",
          },
          {
            title: "Intro to Records Management for Nonprofits",
            platform: "Coursera",
            duration: "50 mins",
          },
        ],
        quiz: {
          title: "Record-Keeping & Documentation Quiz",
          duration: "12 mins",
        },
      },
      {
        title: "Handling Donations & Contributions",
        description:
          "Training on properly documenting and managing donations, pledges, and in-kind contributions.",
        courses: [
          {
            title: "Nonprofit Donation Management",
            platform: "YouTube by Candid",
            duration: "30 mins",
          },
          {
            title: "Basics of Handling Contributions",
            platform: "LinkedIn Learning",
            duration: "45 mins",
          },
          {
            title: "Donation Documentation & Acknowledgments",
            platform: "Skillshare",
            duration: "25 mins",
          },
          {
            title: "Recording Donations and Pledges",
            platform: "Coursera",
            duration: "50 mins",
          },
          {
            title: "Fundraising and Donation Tracking",
            platform: "YouTube by Fundraising Academy",
            duration: "40 mins",
          },
        ],
        quiz: {
          title: "Handling Donations & Contributions Quiz",
          duration: "15 mins",
        },
      },
      {
        title: "Financial Compliance & Reporting",
        description:
          "Understanding reporting requirements and how to ensure compliance with financial regulations.",
        courses: [
          {
            title: "Nonprofit Financial Compliance",
            platform: "YouTube by Candid",
            duration: "50 mins",
          },
          {
            title: "Intro to Compliance for Financial Officers",
            platform: "LinkedIn Learning",
            duration: "45 mins",
          },
          {
            title: "Understanding Financial Regulations",
            platform: "Coursera",
            duration: "30 mins",
          },
          {
            title: "Financial Reporting Essentials for Nonprofits",
            platform: "Skillshare",
            duration: "25 mins",
          },
          {
            title: "Intro to Financial Compliance",
            platform: "YouTube by Harvard",
            duration: "40 mins",
          },
        ],
        quiz: {
          title: "Financial Compliance & Reporting Quiz",
          duration: "15 mins",
        },
      },
      {
        title: "Communication & Confidentiality in Financial Matters",
        description:
          "Ensuring financial communications are handled securely and confidentially.",
        courses: [
          {
            title: "Handling Confidential Information",
            platform: "LinkedIn Learning",
            duration: "30 mins",
          },
          {
            title: "Professional Communication Skills",
            platform: "Coursera",
            duration: "40 mins",
          },
          {
            title: "Confidentiality Best Practices",
            platform: "YouTube by Skillshare",
            duration: "25 mins",
          },
          {
            title: "Communicating with Donors",
            platform: "LinkedIn Learning",
            duration: "50 mins",
          },
          {
            title: "Data Security and Confidentiality",
            platform: "Coursera",
            duration: "45 mins",
          },
        ],
        quiz: {
          title: "Communication & Confidentiality Quiz",
          duration: "12 mins",
        },
      },
      {
        title: "Financial Tools & Software for Nonprofits",
        description:
          "Training on using financial software tools relevant to nonprofits (e.g., QuickBooks, Excel).",
        courses: [
          {
            title: "Using Excel for Financial Tracking",
            platform: "LinkedIn Learning",
            duration: "45 mins",
          },
          {
            title: "QuickBooks Basics",
            platform: "YouTube by QuickBooks",
            duration: "50 mins",
          },
          {
            title: "Intro to Financial Tools for Nonprofits",
            platform: "Skillshare",
            duration: "30 mins",
          },
          {
            title: "Microsoft Excel Basics for Finance",
            platform: "Coursera",
            duration: "40 mins",
          },
          {
            title: "Fundamentals of Using Financial Software",
            platform: "LinkedIn Learning",
            duration: "50 mins",
          },
        ],
        quiz: {
          title: "Financial Tools & Software Quiz",
          duration: "15 mins",
        },
      },
    ],
  },
  "corresponding-secretary": {
    name: "Corresponding Secretary",
    description:
      "The Corresponding Secretary manages organizational correspondence, meeting notes, and event invitations.",
    attributes: [
      {
        title: "Professional Writing & Email Etiquette",
        description:
          "Basics of professional writing, email management, and etiquette in official correspondence.",
        courses: [
          {
            title: "Email and Writing Etiquette",
            platform: "LinkedIn Learning",
            duration: "30 mins",
          },
          {
            title: "Professional Email Communication",
            platform: "YouTube by Skillshare",
            duration: "25 mins",
          },
          {
            title: "Writing Effective Emails",
            platform: "Coursera",
            duration: "50 mins",
          },
          {
            title: "Writing with Clarity and Professionalism",
            platform: "LinkedIn Learning",
            duration: "40 mins",
          },
          {
            title: "Business Email Best Practices",
            platform: "YouTube by Harvard",
            duration: "45 mins",
          },
        ],
        quiz: {
          title: "Professional Writing & Email Etiquette Quiz",
          duration: "12 mins",
        },
      },
      {
        title: "Record-Keeping & Meeting Documentation",
        description:
          "How to take minutes, organize notes, and distribute documentation effectively.",
        courses: [
          {
            title: "How to Take Meeting Minutes",
            platform: "LinkedIn Learning",
            duration: "30 mins",
          },
          {
            title: "Documenting and Organizing Minutes",
            platform: "YouTube by Skillshare",
            duration: "40 mins",
          },
          {
            title: "Basics of Meeting Documentation",
            platform: "Coursera",
            duration: "45 mins",
          },
          {
            title: "Organizing Meeting Records",
            platform: "YouTube by FutureLearn",
            duration: "50 mins",
          },
          {
            title: "Documenting Official Meetings",
            platform: "LinkedIn Learning",
            duration: "30 mins",
          },
        ],
        quiz: {
          title: "Record-Keeping & Meeting Documentation Quiz",
          duration: "15 mins",
        },
      },
      {
        title: "Calendar Management & Scheduling",
        description:
          "Techniques for managing organizational calendars, scheduling meetings, and sending reminders.",
        courses: [
          {
            title: "Google Calendar Tips and Tricks",
            platform: "YouTube by Udemy",
            duration: "30 mins",
          },
          {
            title: "Microsoft Outlook Calendar Basics",
            platform: "LinkedIn Learning",
            duration: "45 mins",
          },
          {
            title: "Time and Calendar Management",
            platform: "Skillshare",
            duration: "25 mins",
          },
          {
            title: "Efficient Scheduling Techniques",
            platform: "YouTube by Harvard",
            duration: "35 mins",
          },
          {
            title: "Setting Up Organizational Schedules",
            platform: "LinkedIn Learning",
            duration: "50 mins",
          },
        ],
        quiz: {
          title: "Calendar Management & Scheduling Quiz",
          duration: "12 mins",
        },
      },
      {
        title: "Digital Tools for Communication & Organization",
        description:
          "Training on communication and organizational tools like Google Workspace, Slack, and Asana.",
        courses: [
          {
            title: "Slack for Effective Team Communication",
            platform: "YouTube by Slack",
            duration: "25 mins",
          },
          {
            title: "Intro to Google Workspace",
            platform: "LinkedIn Learning",
            duration: "45 mins",
          },
          {
            title: "Using Trello for Task Management",
            platform: "Skillshare",
            duration: "30 mins",
          },
          {
            title: "Microsoft Teams for Communication",
            platform: "Coursera",
            duration: "40 mins",
          },
          {
            title: "Organizing and Sharing Files on Google Drive",
            platform: "YouTube by Google",
            duration: "30 mins",
          },
        ],
        quiz: {
          title: "Digital Tools for Communication Quiz",
          duration: "15 mins",
        },
      },
      {
        title: "Public Relations & Community Engagement",
        description:
          "Skills for effectively communicating with the public and promoting events.",
        courses: [
          {
            title: "Intro to Community Engagement",
            platform: "YouTube by Candid",
            duration: "40 mins",
          },
          {
            title: "Basics of Public Relations",
            platform: "LinkedIn Learning",
            duration: "45 mins",
          },
          {
            title: "Building Positive Community Relations",
            platform: "Coursera",
            duration: "50 mins",
          },
          {
            title: "Social Media Basics for Community Outreach",
            platform: "Skillshare",
            duration: "25 mins",
          },
          {
            title: "Intro to Public Relations",
            platform: "YouTube by Udemy",
            duration: "30 mins",
          },
        ],
        quiz: {
          title: "Public Relations & Community Engagement Quiz",
          duration: "15 mins",
        },
      },
    ],
  },
  chaplain: {
    name: "Chaplain",
    description:
      "The Chaplain provides spiritual guidance and may lead events such as invocations or memorials.",
    attributes: [
      {
        title: "Public Speaking & Inspirational Messaging",
        description:
          "Techniques for delivering messages with empathy, inspiration, and clarity.",
        courses: [
          {
            title: "Public Speaking Essentials",
            platform: "YouTube by Skillshare",
            duration: "30 mins",
          },
          {
            title: "How to Inspire Others with Words",
            platform: "LinkedIn Learning",
            duration: "40 mins",
          },
          {
            title: "Introduction to Inspirational Speaking",
            platform: "Coursera",
            duration: "45 mins",
          },
          {
            title: "Confidence in Public Speaking",
            platform: "YouTube by Stanford",
            duration: "50 mins",
          },
          {
            title: "Storytelling for Impact",
            platform: "LinkedIn Learning",
            duration: "55 mins",
          },
        ],
        quiz: {
          title: "Public Speaking & Inspirational Messaging Quiz",
          duration: "12 mins",
        },
      },
      {
        title: "Cultural & Religious Sensitivity",
        description:
          "Training on understanding diverse spiritual practices and being sensitive to all backgrounds.",
        courses: [
          {
            title: "Understanding Cultural Sensitivity",
            platform: "YouTube by FutureLearn",
            duration: "30 mins",
          },
          {
            title: "Basics of Religious Literacy",
            platform: "LinkedIn Learning",
            duration: "45 mins",
          },
          {
            title: "Introduction to Religious Studies",
            platform: "Coursera",
            duration: "50 mins",
          },
          {
            title: "Practicing Cultural Competence",
            platform: "YouTube by Harvard",
            duration: "40 mins",
          },
          {
            title: "Sensitivity Training for Volunteers",
            platform: "Skillshare",
            duration: "25 mins",
          },
        ],
        quiz: {
          title: "Cultural & Religious Sensitivity Quiz",
          duration: "15 mins",
        },
      },
      {
        title: "Supporting Volunteers' Emotional Wellbeing",
        description:
          "Skills for providing emotional support and recognizing signs of stress in team members.",
        courses: [
          {
            title: "Basics of Emotional Wellbeing in the Workplace",
            platform: "LinkedIn Learning",
            duration: "30 mins",
          },
          {
            title: "Managing Mental Health at Work",
            platform: "YouTube by Harvard",
            duration: "45 mins",
          },
          {
            title: "Building Resilience and Empathy",
            platform: "Coursera",
            duration: "50 mins",
          },
          {
            title: "Introduction to Emotional Intelligence",
            platform: "Skillshare",
            duration: "30 mins",
          },
          {
            title: "Mental Health First Aid for Leaders",
            platform: "YouTube by FutureLearn",
            duration: "40 mins",
          },
        ],
        quiz: {
          title: "Supporting Emotional Wellbeing Quiz",
          duration: "12 mins",
        },
      },
      {
        title: "Organizing Ceremonial & Memorial Events",
        description:
          "Planning and conducting ceremonies or memorials that reflect organizational values.",
        courses: [
          {
            title: "Planning Special Events",
            platform: "LinkedIn Learning",
            duration: "40 mins",
          },
          {
            title: "Intro to Event Ceremonies",
            platform: "YouTube by Udemy",
            duration: "35 mins",
          },
          {
            title: "Basics of Memorial Service Planning",
            platform: "Coursera",
            duration: "50 mins",
          },
          {
            title: "Effective Event Coordination",
            platform: "Skillshare",
            duration: "30 mins",
          },
          {
            title: "Handling Memorial Events with Compassion",
            platform: "LinkedIn Learning",
            duration: "45 mins",
          },
        ],
        quiz: {
          title: "Organizing Ceremonial & Memorial Events Quiz",
          duration: "15 mins",
        },
      },
      {
        title: "Ethical Considerations & Confidentiality",
        description:
          "Ensuring confidentiality and ethical conduct in all interactions.",
        courses: [
          {
            title: "Ethics in Volunteer Roles",
            platform: "YouTube by FutureLearn",
            duration: "45 mins",
          },
          {
            title: "Confidentiality Basics",
            platform: "LinkedIn Learning",
            duration: "30 mins",
          },
          {
            title: "Understanding Professional Ethics",
            platform: "Coursera",
            duration: "50 mins",
          },
          {
            title: "Handling Sensitive Information",
            platform: "Skillshare",
            duration: "25 mins",
          },
          {
            title: "Ethics and Confidentiality",
            platform: "YouTube by Harvard",
            duration: "40 mins",
          },
        ],
        quiz: {
          title: "Ethical Considerations & Confidentiality Quiz",
          duration: "12 mins",
        },
      },
    ],
  },
  parliamentarian: {
    name: "Parliamentarian",
    description:
      "The Parliamentarian ensures meetings follow procedural rules and provides guidance on decision-making processes.",
    attributes: [
      {
        title: "Parliamentary Procedure & Robert's Rules of Order",
        description:
          "A detailed workshop on parliamentary procedures to run meetings smoothly.",
        courses: [
          {
            title: "Basics of Parliamentary Procedure",
            platform: "LinkedIn Learning",
            duration: "30 mins",
          },
          {
            title: "Robert's Rules of Order Simplified",
            platform: "YouTube by Udemy",
            duration: "50 mins",
          },
          {
            title: "Introduction to Robert's Rules",
            platform: "Coursera",
            duration: "45 mins",
          },
          {
            title: "Running Meetings with Parliamentary Procedure",
            platform: "Skillshare",
            duration: "25 mins",
          },
          {
            title: "Fundamentals of Meeting Procedure",
            platform: "YouTube by Harvard",
            duration: "40 mins",
          },
        ],
        quiz: {
          title: "Parliamentary Procedure & Robert's Rules Quiz",
          duration: "15 mins",
        },
      },
      {
        title: "Conflict Resolution & Mediation",
        description:
          "Strategies for handling disagreements in a neutral, procedural manner.",
        courses: [
          {
            title: "Conflict Resolution Skills",
            platform: "LinkedIn Learning",
            duration: "45 mins",
          },
          {
            title: "Introduction to Mediation",
            platform: "YouTube by Coursera",
            duration: "40 mins",
          },
          {
            title: "Handling Conflict at Meetings",
            platform: "Skillshare",
            duration: "30 mins",
          },
          {
            title: "Basics of Mediation",
            platform: "Coursera",
            duration: "50 mins",
          },
          {
            title: "Practical Mediation Skills",
            platform: "LinkedIn Learning",
            duration: "55 mins",
          },
        ],
        quiz: {
          title: "Conflict Resolution & Mediation Quiz",
          duration: "12 mins",
        },
      },
      {
        title: "Meeting Facilitation & Agenda Setting",
        description:
          "Training on effective agenda-setting and meeting facilitation practices.",
        courses: [
          {
            title: "How to Facilitate Effective Meetings",
            platform: "LinkedIn Learning",
            duration: "40 mins",
          },
          {
            title: "Creating an Agenda for Meetings",
            platform: "YouTube by Skillshare",
            duration: "30 mins",
          },
          {
            title: "Meeting Facilitation Essentials",
            platform: "Coursera",
            duration: "45 mins",
          },
          {
            title: "Making Meetings Productive",
            platform: "LinkedIn Learning",
            duration: "55 mins",
          },
          {
            title: "Leading Structured Meetings",
            platform: "YouTube by Harvard",
            duration: "50 mins",
          },
        ],
        quiz: {
          title: "Meeting Facilitation & Agenda Setting Quiz",
          duration: "15 mins",
        },
      },
      {
        title: "Policy Review & Organizational Governance",
        description:
          "Understanding organizational policies and governance structures for compliance.",
        courses: [
          {
            title: "Introduction to Organizational Governance",
            platform: "LinkedIn Learning",
            duration: "45 mins",
          },
          {
            title: "Understanding Policy Review",
            platform: "YouTube by FutureLearn",
            duration: "30 mins",
          },
          {
            title: "Basics of Nonprofit Governance",
            platform: "Coursera",
            duration: "50 mins",
          },
          {
            title: "Creating Effective Policies",
            platform: "Skillshare",
            duration: "25 mins",
          },
          {
            title: "Organizational Policy Review",
            platform: "LinkedIn Learning",
            duration: "40 mins",
          },
        ],
        quiz: {
          title: "Policy Review & Organizational Governance Quiz",
          duration: "15 mins",
        },
      },
      {
        title: "Ethical Decision-Making in Governance",
        description:
          "Guiding ethical decision-making and maintaining impartiality in governance roles.",
        courses: [
          {
            title: "Ethics and Leadership",
            platform: "LinkedIn Learning",
            duration: "45 mins",
          },
          {
            title: "Making Ethical Decisions",
            platform: "Coursera",
            duration: "40 mins",
          },
          {
            title: "Intro to Governance Ethics",
            platform: "YouTube by Harvard",
            duration: "50 mins",
          },
          {
            title: "Ethical Leadership for Nonprofits",
            platform: "Skillshare",
            duration: "30 mins",
          },
          {
            title: "Foundations of Ethical Decision-Making",
            platform: "YouTube by Udemy",
            duration: "30 mins",
          },
        ],
        quiz: {
          title: "Ethical Decision-Making in Governance Quiz",
          duration: "12 mins",
        },
      },
    ],
  },
};